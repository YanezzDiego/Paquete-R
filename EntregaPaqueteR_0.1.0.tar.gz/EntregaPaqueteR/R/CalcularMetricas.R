#' Calcular Métricas para Atributos de un Dataset
#'
#' @description Función para calcular métricas de un Dataset.
#' Para variables discretas se obtiene la entropía. Para variables continuas varianza y AUC con respecto a una variable binaria la cual se debe especificar.
#'
#' @param data Un data frame con variables discretas y/o continuas.
#' @param clase Nombre de la variable Y, utilizada para calcular el AUC en las variables numéricas.
#' @param include Puede ser `TRUE` o `FALSE` para incluir o no métricas de variables categóricas. `TRUE` por defecto.
#' @param only_categorical Puede ser `TRUE` o `FALSE` para incluir o no métricas de variables numéricas `TRUE` por defecto.
#' @param plot Puede ser `TRUE` o `FALSE` para incluir o no un gráfico de AUC para la variable `plot_col`
#' @param plot_col Nombre de la columna para graficar AUC cuando `plot = TRUE`.
#' @return Una lista con las métricas calculadas para cada variable en el dataset .
#' @examples
#' # Ejemplo 1: Con una variable binaria para calcular el AUC y una variable categórica discreta
#' data <- mtcars
#'
#' Se debe incluir una variable Y a predecir, por lo cual se tomará la variable 'vs' como tal.
#' data$vs <- as.factor(data$vs)  # Variable binaria para la clase Y
#' set.seed(123)
#' data$grupo_discreto <- sample(c("A", "B", "C"), nrow(data), replace = TRUE)  # Variable categórica discreta
#'
#' # Calcular métricas con gráfico ROC de la columna 'mpg' y cálculo de entropía para 'grupo_discreto'
#' resultados1 <- calcular_metricas(data, clase = "vs", include = TRUE, only_categorical = FALSE, plot = TRUE, plot_col = "mpg")
#' print(resultados1)
#'
#' # Ejemplo 2: Sin gráficos y solo métricas para variables categóricas (entropía de 'grupo_discreto' y 'vs')
#' resultados2 <- calcular_metricas(data, clase = "vs", include = TRUE, only_categorical = TRUE, plot = FALSE)
#' print(resultados2)
#'
#' # Ejemplo 3: Sin gráficos y cálculo de varianza y AUC para variables numéricas, excluyendo métricas de variables categóricas
#' resultados3 <- calcular_metricas(data, clase = "vs", include = FALSE, only_categorical = FALSE, plot = FALSE)
#' print(resultados3)
#'
#' # Ejemplo 4: Gráfico de ROC para la columna 'hp' y cálculo de métricas tanto para variables numéricas como categóricas
#' resultados4 <- calcular_metricas(data, clase = "vs", include = TRUE, only_categorical = FALSE, plot = TRUE, plot_col = "hp")
#' print(resultados4)
#'
#' # Ejemplo 5: Solo cálculo de entropía para variables categóricas (sin AUC y sin gráfico)
#' resultados5 <- calcular_metricas(data, include = TRUE, only_categorical = TRUE, plot = FALSE)
#' print(resultados5)
#' @export
calcular_metricas <- function(data, clase = NULL, include = TRUE, only_categorical = FALSE, plot = FALSE, plot_col = NULL) {

  # Función para calcular entropía
  entropy <- function(x) {
    x <- factor(x)
    probabilidades <- table(x) / length(x)
    H <- sum(-probabilidades * log(probabilidades, 2))
    return(H)
  }

  # Función para calcular ROC, AUC y graficar si plot = TRUE y la columna coincide con plot_col
  roc_auc <- function(x, y, should_plot, var_name) {
    ordenado <- order(x, decreasing = TRUE)
    x <- x[ordenado]
    y <- y[ordenado]

    TPR <- c()
    FPR <- c()
    for (valor_corte in unique(x)) {
      Y_pred <- x > valor_corte
      TP <- sum(y == 1 & Y_pred == TRUE)
      TN <- sum(y == 0 & Y_pred == FALSE)
      FP <- sum(y == 0 & Y_pred == TRUE)
      FN <- sum(y == 1 & Y_pred == FALSE)

      tpr <- TP / (TP + FN)
      fpr <- FP / (FP + TN)

      TPR <- c(TPR, tpr)
      FPR <- c(FPR, fpr)
    }

    # Cálculo de AUC usando el método del trapecio
    auc <- sum(diff(FPR) * (head(TPR, -1) + tail(TPR, -1)) / 2)

    # Graficar la curva ROC si should_plot = TRUE
    if (should_plot) {
      plot(FPR, TPR, type = "l", col = "blue",
           xlab = "FPR (False Positive Rate)", ylab = "TPR (True Positive Rate)",
           main = paste("Curva ROC para", var_name, "- AUC:", round(auc, 2)))
    }

    return(auc)
  }

  # Convertir la clase a formato binario si es factor
  if (!is.null(clase) && is.factor(data[[clase]])) {
    data[[clase]] <- as.numeric(data[[clase]]) - 1
  }

  # Lista para almacenar resultados
  resultados <- list()

  # Iterar sobre cada columna del dataset
  for (col in names(data)) {
    # Calcular entropía si es una variable categórica
    if (only_categorical && (is.factor(data[[col]]) || is.character(data[[col]]))) {
      ent <- entropy(data[[col]])
      resultados[[col]] <- list(entropia = ent)

    } else if (!only_categorical) {
      if (is.numeric(data[[col]])) {
        # Calcular varianza para variables continuas
        varianza <- var(data[[col]], na.rm = TRUE)
        resultados[[col]] <- list(varianza = varianza)

        # Calcular AUC si hay una clase binaria especificada
        #Se grafica si es que existe una variable Y dentro del data frame que debe ser especificada por el usuario
        #Si no está defiinida la clase, no se calcula auc ni habrá gráfico.
        if (!is.null(clase) && clase %in% names(data) && length(unique(data[[clase]])) == 2) {
          # Verificar si se debe graficar esta columna
          should_plot <- plot && !is.null(plot_col) && col == plot_col
          auc <- roc_auc(data[[col]], data[[clase]], should_plot, var_name = col)
          resultados[[col]]$AUC <- auc
        }

      } else if (include && (is.factor(data[[col]]) || is.character(data[[col]]))) {
        # Calcular entropía para variables categóricas solo si include = TRUE
        ent <- entropy(data[[col]])
        resultados[[col]] <- list(entropia = ent)
      }
    }
  }

  return(resultados)
}

