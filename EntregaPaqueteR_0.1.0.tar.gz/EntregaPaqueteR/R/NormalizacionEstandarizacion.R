#' Transformación de Datos: Normalización o Estandarización
#'
#' @description Función para aplicar técnicas de transformación de datos.
#' Normaliza los datos (media 0 y desviación estándar 1) o estandariza los datos (valores entre 0 y 1) a todas las columnas numéricas de un dataset.
#'
#' @details
#' La función incluye dos técnicas comunes de transformación de datos:
#'
#' *Normalización*: Ajusta los datos para que tengan una media de 0 y una desviación estándar de 1.
#' Este método es útil cuando los datos se distribuyen en torno a una media y se desea resaltar las variaciones
#' en términos de desviaciones estándar.
#'
#' *Estandarización*: Escala los valores para que se ubiquen en un rango entre 0 y 1. Este método es útil para
#' comparar variables que se encuentran en escalas diferentes, ya que estandariza todas las columnas numéricas al
#' mismo rango, facilitando el análisis comparativo.
#'
#' @param data Un data frame con columnas numéricas y no numéricas.
#' @param method Un método de transformación: "normalizacion" para media 0 y desviación estándar 1, o "estandarizacion" para escalar entre 0 y 1.
#' @return Un data frame con las columnas numéricas transformadas según el método elegido.
#' @examples
#' data <- data.frame(a = c(1, 2, 3, 4, 5), b = c(10, 20, 30, 40, 50), c = c("A", "B", "C", "D", "E"))
#' estandarizacion <- transform_data(data, method = "estandarizacion")
#' print(estandarizacion)
#'
#' normalizacion <- transform_data(data, method = "normalizacion")
#' print(normalizacion)
#' @export
transform_data <- function(data, method = c("normalizacion", "estandarizacion")) {

  # Selección del método de transformación
  method <- match.arg(method)

  # Función para estandarizar entre 0 y 1
  estandarizacion <- function(x) {
    x_estandarizado <- (x - min(x)) / (max(x) - min(x))
    return(x_estandarizado)
  }

  # Función para normalizar a media 0 y desviación estándar 1
  normalizacion <- function(v) {
    vmedio <- mean(v)
    dest <- sd(v)
    v_normalizado <- (v - vmedio) / dest
    return(v_normalizado)
  }

  # Aplicar la transformación a cada columna numérica del dataset
  for (col in names(data)) {
    if (is.numeric(data[[col]])) {
      if (method == "estandarizacion") {
        data[[col]] <- estandarizacion(data[[col]])
        print(paste("La variable", col, "ha sido estandarizada con éxito"))
      } else if (method == "normalizacion") {
        data[[col]] <- normalizacion(data[[col]])
        print(paste("La variable", col, "ha sido normalizada con éxito"))
      }
    }
  }

  return(data)
}

