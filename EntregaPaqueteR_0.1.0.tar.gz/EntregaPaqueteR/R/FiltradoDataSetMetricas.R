#' Filtrar Data frames por métricas AUC, VAR y ENTROPIA
#' @description Función para filtrar data set.
#'
#' Da la posibilidad de elegir entre tres métodos: "auc", "var" y "entropy" para filtrar.
#' Se requiere que todo el data frame sea del mismo tipo (solo categórico o solo numérico)
#'
#' @param data Data frame a filtrar (debe ser solo numérico o solo categórico).
#' @param method Método de filtrado: "entropy", "var", "auc".
#' @param operator Operador lógico para comparar la métrica y el umbral ("<", ">", "=", "<=", ">=").
#' @param umbral Umbral numérico que se debe satisfacer.
#' @param col Columnas a incluir en el cálculo del filtro (todas por defecto).
#' @param y Variable dependiente para el cálculo de AUC (solo necesario para método "auc").
#' @return Un data frame filtrado con las variables que cumplen con el filtro.
#' @export
#'
#' @examples
#' # Filtrar dataset por entropía mayor a 0.5 en un dataset categórico
#' ejemplo_enteropia <- data.frame(
#'   A = factor(c("a", "b", "a", "a", "b")),
#'   B = factor(c("x", "x", "y", "y", "z")),
#'   C = factor(c("apple", "banana", "apple", "apple", "banana"))
#' )
#' filtrar_variables(ejemplo_enteropia, method = "entropy", operator = ">", umbral = 0.5)
#'
#' # Filtrar AUC mayor a 0.6 en un dataset numérico con variable dependiente
#' ejemplo_auc <- data.frame(
#'   Variable1 = c(0.2, 0.8, 0.5, 0.7, 0.3),
#'   Variable2 = c(0.4, 0.6, 0.7, 0.3, 0.9),
#'   Variable3 = c(0.1, 0.5, 0.4, 0.8, 0.6),
#'   y = c(TRUE, FALSE, TRUE, FALSE, TRUE)  # Variable dependiente binaria
#' )
#' filtrar_variables(ejemplo_auc, method = "auc", operator = ">", umbral = 0.6, y = "y")
#'
#' # Filtrar dataset por varianza mayor a 0.1 en un dataset numérico
#' ejemplo_var <- data.frame(
#'   Var1 = c(1.2, 2.3, 1.8, 2.5, 1.9),
#'   Var2 = c(3.4, 3.6, 3.5, 3.7, 3.4),
#'   Var3 = c(0.5, 0.7, 0.6, 0.9, 0.8)
#' )
#' filtrar_variables(ejemplo_var, method = "var", operator = ">", umbral = 0.1)

filtrar_dataset <- function(data, method = c("entropy", "var", "auc"), operator, umbral, col = NULL, y = NULL) {
  method <- match.arg(method)

  # DF debe ser solo numérico o categórico
  if (method == "auc" && any(!sapply(data[, 1:(ncol(data) - 1)], is.numeric))) {
    stop("Para calcular auc, el df debe ser solo numérico")
  }

  if (method == "var" && any(!sapply(data, is.numeric))) {
    stop("Para calcular var, el df debe ser solo numérico")
  }

  if (method == "entropy" && any(sapply(data, is.numeric))) {
    stop("Para calcular entropía, el df debe ser solo categórico.")
  }

  # Entropía
  entropy <- function(x) {
    x <- factor(x)
    probabilidades <- table(x) / length(x)
    H <- sum(-probabilidades * log(probabilidades, 2))
    return(H)
  }

  # AUC
  auc <- function(df) {
    df <- df[order(df$X, decreasing = TRUE), ]
    TPR <- c()
    FPR <- c()
    corte <- c()

    for (valor_corte in unique(df$X)) {
      Y_pred <- df$X > valor_corte
      TP <- sum(df$Y == TRUE & Y_pred == TRUE)
      TN <- sum(df$Y == FALSE & Y_pred == FALSE)
      FP <- sum(df$Y == FALSE & Y_pred == TRUE)
      FN <- sum(df$Y == TRUE & Y_pred == FALSE)

      tpr <- TP / (TP + FN)
      fpr <- FP / (FP + TN)

      TPR <- c(TPR, tpr)
      FPR <- c(FPR, fpr)
      corte <- c(corte, valor_corte)
    }

    auc <- sum(diff(FPR) * (head(TPR, -1) + tail(TPR, -1)) / 2)
    return(auc)
  }

  # Si el usuario no especifica el nombre de las columnas sobre las cuales se filtrará, entonces se filtra sobre todo el df.
  if (is.null(col)) col <- names(data)

  # Se valida que para cuando se seleccione auc, debe existir una variable objetivo.
  if (method == "auc" && is.null(y)) stop("Para filtrar por AUC se debe especificar la variable objetivo y")

  # Conversión de tipos de datos
  data[col] <- lapply(data[col], function(x) {
    if (is.character(x)) as.factor(x)
    else if (is.numeric(x)) as.numeric(x)
    else x
  })

  columnas_seleccionadas <- col # proviene del names(data), son todas las columnas sobre las cuales se hace el filtro. Por defecto

  # Se filtra para cada columna
  for (columna in col) {
    # Cálculo de métrica según método
    valor_metrica <- switch(
      method,
      "entropy" = entropy(data[[columna]]),
      "var" = var(data[[columna]], na.rm = TRUE),
      "auc" = auc(data.frame(X = data[[columna]], Y = data[[y]]))
    )

    # Evaluar condición sin usar eval(parse())
    comparacion <- do.call(operator, list(valor_metrica, umbral))
    if (!comparacion) {
      columnas_seleccionadas <- setdiff(columnas_seleccionadas, columna)
    }
  }

  # Retorna el data frame filtrado con solo las columnas seleccionadas
  return(data[, columnas_seleccionadas, drop = FALSE])
}


