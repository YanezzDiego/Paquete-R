#' Algoritmos de discretización
#'
#' @description Función para discretizar data frames o vectores por técnicas de Igual Frecuencia o Igual Anchura.
#'
#' @param data Un data frame o un vector.
#' @param col Columna a discretizar en caso de ser data frame; si es NULL, se aplicará a todas las columnas numéricas.
#' @param num_bins Número de intervalos.
#' @param method Tipo de discretización para los datos: "equal_freq" o "equal_width".
#' @return Lista con columna(s) discretizada(s) y los puntos de corte.
#' @examples
#' data <- mtcars[, 1:7]
#' data_EF <- discretize(data, "mpg", 5, "equal_freq")
#' data_EW <- discretize(data, num_bins = 5, method = "equal_width")
#' @export

discretize <- function(data, col = NULL, num_bins = 5, method = "equal_width") {

  # Discretizacion EF
  discretizeEF <- function(v,num_bins){
    if(!is.numeric(v)){
      stop("El vector de entrada debe ser numérico.")
    }
    if(num_bins<1){
      stop("El número de num_bins debe ser mayor que 1")
    }

    v_ordenado <- sort(v)
    num_por_intervalo <- ceiling(length(v) / num_bins) #Redondeo al entero superior
    quiebres <- v_ordenado[seq(num_por_intervalo, length(v_ordenado), num_por_intervalo)]

    # Añadir -Inf al principio y +Inf al final
    quiebres <- c(-Inf, quiebres, Inf)

    # Discretizar los valores
    categorial_result <- cut(v, breaks = quiebres, include.lowest = TRUE, right = FALSE)

    # Devolver el resultado como lista
    return(list(categorical = categorial_result, cuts = quiebres[2:num_bins]))
  }

  # EW
  discretizeEW <- function(v,num_bins){
    if(!is.numeric(v)){
      stop("El vector de entrada debe ser numérico.")
    }
    if(num_bins<1){
      stop("El número de num_bins debe ser mayor que 1")
    }
    anchura = (max(v)-min(v))/num_bins
    quiebres <- c(-Inf, seq(min(v) + anchura, max(v) - anchura, by = anchura), Inf)
    #quiebres <- seq(min(v),max(v),by=anchura)

    categorial_result <- cut(v, breaks = quiebres, include.lowest = TRUE, right = FALSE)


    return(list(categorical = categorial_result, cuts = quiebres[2:num_bins]))
  }
  # Si data es vector, aplicamos la discretización directamente sobre el vector
  if (is.vector(data)) {
    return(switch(
      method,
      equal_freq = discretizeEF(data, num_bins),
      equal_width = discretizeEW(data, num_bins),
      stop("Método de discretización desconocido")
    ))
  } else if (is.data.frame(data)) {

    # Selección de las columnas numéricas o la columna especificada
    columns <- if (!is.null(col)) col else names(data)
    results <- list()

    # Aplica la disccretizacion sobre todo el df
    for (column in columns) {
      if (is.numeric(data[[column]])) {
        results[[column]] <- switch(
          method,
          equal_freq = discretizeEF(data[[column]], num_bins),
          equal_width = discretizeEW(data[[column]], num_bins),
          stop("Método de discretización desconocido")
        )
      } else {
        warning(paste("La columna", column, "no es numérica y se omitirá."))
      }
    }
    return(results)
  } else {
    stop("El argumento 'data' debe ser un vector numérico o un data frame.")
  }
}


