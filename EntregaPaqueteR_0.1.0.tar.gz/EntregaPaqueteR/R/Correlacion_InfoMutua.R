#' Obtención de Información Mutua y Correlaciones
#'
#' @description Esta función obtiene tanto la correlación entre pares de variables numéricas como la información mútua entre pares de variables categóricas.
#' Además grafica los resultados y da la opción de exportar el gráfico obtenido.
#'
#' @details
#' La correlación y la información mutua son dos métodos distintos para medir relaciones entre variables:
#'
#' *Correlación*: Mide la asociación lineal entre dos variables numéricas y toma valores entre -1 y 1. Un valor cercano a 1 indica una fuerte correlación positiva (ambas variables aumentan o disminuyen conjuntamente), mientras que un valor cercano a -1 indica una fuerte correlación negativa (una variable aumenta mientras la otra disminuye). Una correlación igual a 0 indica ausencia de una relación lineal entre las variables.
#'
#' *Información Mutua*: La información mutua mide la dependencia entre variables categóricas, indicando cuánta información se puede obtener de una variable observando otra. Valores más altos de información mutua indican una mayor dependencia entre las variables, mientras que un valor de 0 indica independencia completa. La información mutua está normalizada en un rango de 0 a 1 en esta función.
#'
#' @param df Un data frame con variables numéricas y/o categóricas.
#' @param exportar Puede ser `TRUE` o `FALSE` dependiendo si se quiere exportar un gráfico o no.
#' @param nombre Ruta del gráfico exportado. Si no se define, se toma como ruta el valor de la variable.
#' @param plot Puede ser `TRUE` o `FALSE` para mostrar o no el gráfico (por defecto es `TRUE`).
#' @param fill Si se requiere la matriz completa o solo la matriz superior. (`upper` o `fill`)
#' @param colores Una paleta de tres colores para el gráfico. Por defecto c(`red`,`white`,`blue`)
#' @return Una lista con dos elementos: `matriz_correlacion` y `matriz_info_mutua`, cada uno siendo una matriz que contiene la correlación o la información mutua entre cada pares de variables categóricas o numéricas respetivamente.
#' @examples
#' data(mtcars)
#' mtcars$cyl <- as.factor(mtcars$cyl)  # Convertir una columna en categórica
#'
#' #Se obtiene la matriz de correlaciones y la matriz de información mutua.
#' resultado <- Cor_InfoMutua(mtcars)
#'
#' #Se visualiza la matriz de correlación.
#' print(resultado$matriz_correlacion)
#'
#' #Se visualiza la matriz de información mutua.
#' print(resultado$matriz_info_mutua)
#'
#' #Se pueden modificar los colores por defecto del gráfico.
#' Cor_InfoMutua(mtcars, colores = c("green", "yellow", "purple"))
#'
#' #Se puede exportar el gráfico generado y también incluir la matriz de correlacion/información mutua completa.
#' Cor_InfoMutua(mtcars, exportar = TRUE, nombre = "mi_correlacion.pdf", fill = "full")
#' @export
Cor_InfoMutua <- function(df, exportar = FALSE, nombre = FALSE, mostrar_plot = TRUE,fill = "upper", colores = c("red", "white", "blue")) {

  # Comprobar si el paquete corrplot está instalado
  if (!requireNamespace("corrplot", quietly = TRUE)) {
    stop("El paquete 'corrplot' no está instalado. Es necesario para graficar.")
  }

  # Función para calcular la entropía de una variable categórica
  entropy <- function(x) {
    x <- factor(x)
    probabilidades <- table(x) / length(x)
    H <- sum(-probabilidades * log(probabilidades, 2))
    return(H)
  }

  # Función para calcular la información mutua entre dos variables categóricas
  calcular_informacion_mutua <- function(x, y) {
    entropia_x <- entropy(x)
    entropia_y <- entropy(y)
    conjunta_xy <- table(x, y) / length(x)
    entropia_conjunta <- -sum(conjunta_xy * log2(conjunta_xy + 1e-10), na.rm = TRUE)
    info_mutua <- entropia_x + entropia_y - entropia_conjunta
    return(info_mutua)
  }

  # Separar el dataset en variables numéricas y categóricas
  df_numerico <- df[sapply(df, is.numeric)]
  df_categorico <- df[sapply(df, is.factor)]

  # Inicializar matrices de resultados para correlación y para información mutua
  matriz_correlacion <- NULL
  matriz_info_mutua <- NULL

  # Calcular la matriz de correlación para variables numéricas
  if (ncol(df_numerico) > 1) {
    matriz_correlacion <- cor(df_numerico, use = "complete.obs")
  }

  # Calcular la información mutua para variables categóricas y normalizarla
  if (ncol(df_categorico) > 1) {
    matriz_info_mutua <- matrix(NA, nrow = ncol(df_categorico), ncol = ncol(df_categorico),
                                dimnames = list(names(df_categorico), names(df_categorico)))
    max_info_mutua <- 0

    for (i in 1:(ncol(df_categorico) - 1)) {
      for (j in (i + 1):ncol(df_categorico)) {
        info_mutua <- calcular_informacion_mutua(df_categorico[[i]], df_categorico[[j]])
        matriz_info_mutua[i, j] <- info_mutua
        matriz_info_mutua[j, i] <- info_mutua
        max_info_mutua <- max(max_info_mutua, info_mutua)
      }
    }

    # Normalizar solo si max_info_mutua es mayor que 0
    if (max_info_mutua > 0) {
      matriz_info_mutua <- matriz_info_mutua / max_info_mutua
    }
  }

  # Combinar ambas matrices para visualizar en una único gráfico.
  matriz_final <- matrix(NA, nrow = ncol(df), ncol = ncol(df),
                         dimnames = list(names(df), names(df)))
  if (!is.null(matriz_correlacion)) {
    matriz_final[rownames(matriz_correlacion), colnames(matriz_correlacion)] <- matriz_correlacion
  }
  if (!is.null(matriz_info_mutua)) {
    matriz_final[rownames(matriz_info_mutua), colnames(matriz_info_mutua)] <- matriz_info_mutua
  }

  # Configurar el nombre y abrir el archivo para exportación si es necesario
  if (exportar == TRUE) {
    if (isFALSE(nombre)) {
      nombre_variable <- deparse(substitute(df))
      nombre_archivo <- paste0(nombre_variable, "_cor_info.pdf")
    } else {
      nombre_archivo <- nombre
    }
    pdf(file = nombre_archivo)
  }

  # Graficar la matriz usando corrplot con la paleta de colores especificada
  if (mostrar_plot || exportar) {
    corrplot::corrplot(matriz_final,
                       method = "color",
                       type = fill,
                       order = "original",
                       tl.col = "black",
                       tl.srt = 45,
                       addCoef.col = "black",
                       number.cex = 0.7,
                       col = colorRampPalette(colores)(200),
                       addshade = "positive",
                       shade.col = "gray",
                       main = "Matriz de Correlación e Información Mutua",
                       mar = c(0, 0, 3, 0))
  }

  # Cerrar el archivo PDF si exportar es TRUE
  if (exportar == TRUE) {
    dev.off()
  }

  # Retornar ambas matrices en una lista.
  return(list(matriz_correlacion = matriz_correlacion, matriz_info_mutua = matriz_info_mutua))
}

