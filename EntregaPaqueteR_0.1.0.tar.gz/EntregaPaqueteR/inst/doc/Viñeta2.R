## -----------------------------------------------------------------------------
library(EntregaPaqueteR)

## -----------------------------------------------------------------------------
?discretize
?Cor_InfoMutua
?filtrar_dataset
?calcular_metricas
?transform_data

