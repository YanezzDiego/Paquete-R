## -----------------------------------------------------------------------------
library(EntregaPaqueteR)

## -----------------------------------------------------------------------------
# Cargamos un dataset de ejemplo y definimos una variable objetivo como factor.
data <- mtcars
data$vs <- as.factor(data$vs) 
data$grupo_discreto <- sample(c("A", "B", "C"), nrow(data), replace = TRUE)  # Variable categórica discreta para ejemplo

## ----fig.width=7.2, fig.height=4----------------------------------------------
resultados1 <- calcular_metricas(data, clase = "vs", include = TRUE, only_categorical = FALSE, plot = TRUE, plot_col = "mpg")
print(resultados1)

## -----------------------------------------------------------------------------
# Calcular solo métricas para variables categóricas
resultados2 <- calcular_metricas(data, clase = "vs", include = TRUE, only_categorical = TRUE, plot = FALSE)
print(resultados2)

## -----------------------------------------------------------------------------
data <- mtcars

## -----------------------------------------------------------------------------
data$cyl <- as.factor(data$cyl) 
data$gear <- as.factor(data$gear)  
data$carb <- as.factor(data$carb) 

## ----fig.width=7.2, fig.height=4----------------------------------------------
resultado <- Cor_InfoMutua(data)

## ----fig.width=7, fig.height=4------------------------------------------------
resultado <- Cor_InfoMutua(data,mostrar_plot=FALSE)

## -----------------------------------------------------------------------------
print(resultado$matriz_info_mutua)   # Muestra la matriz de información mutua

## -----------------------------------------------------------------------------
#Se visualiza la matriz de correlación.
print(resultado$matriz_correlacion)

## ----fig.width=7, fig.height=4------------------------------------------------
Cor_InfoMutua(data, colores = c("green", "yellow", "purple"))

## -----------------------------------------------------------------------------
Cor_InfoMutua(data, exportar = TRUE, nombre = "mi_correlacion_info_mutua.pdf", fill = "full")

## -----------------------------------------------------------------------------
data <- mtcars

## -----------------------------------------------------------------------------
resultado_ef <- discretize(data, col = "mpg", num_bins = 5, method = "equal_freq")
print(resultado_ef$mpg$categorical)  # Muestra la variable 'mpg' discretizada
print(resultado_ef$mpg$cuts)

## -----------------------------------------------------------------------------
resultado_ew <- discretize(data, num_bins = 4, method = "equal_width")
print(resultado_ew)

## -----------------------------------------------------------------------------
ejemplo_entropia <- data.frame(
  A = factor(c("a", "b", "a", "a", "b")),
  B = factor(c("x", "x", "y", "y", "z")),
  C = factor(c("apple", "banana", "apple", "apple", "banana"))
)

## -----------------------------------------------------------------------------

ejemplo_auc <- data.frame(
  Variable1 = c(1, 1, 1, 1, 1),
  Variable2 = c(5, 1,6, 1, 10),
  Variable3 = c(2, 5, 1, 9, 1),
  y = c(TRUE, FALSE, TRUE, FALSE, TRUE)  # Variable dependiente binaria
)

## -----------------------------------------------------------------------------
ejemplo_var <- data.frame(
  Var1 = c(1, 1, 1, 1, 1),
  Var2 = c(3.4, 33, 24, 100, 12),
  Var3 = c(0.5, 0.7, 0.6, 0.9, 0.8)
)

## -----------------------------------------------------------------------------
resultado_entropia <- filtrar_dataset(ejemplo_entropia, method = "entropy", operator = ">", umbral = 0.5)
print(resultado_entropia)

## -----------------------------------------------------------------------------
resultado_auc <- filtrar_dataset(ejemplo_auc, method = "auc", operator = "<", umbral = 0.5, y = "y")
print(resultado_auc)

## -----------------------------------------------------------------------------
resultado_var <- filtrar_dataset(ejemplo_var, method = "var", operator = "==", umbral = 0)
print(resultado_var)

## -----------------------------------------------------------------------------
resultado_var <- filtrar_dataset(ejemplo_var, method = "var", operator = ">", umbral = 1)
print(resultado_var)

## ----fig.show='hold'----------------------------------------------------------
data <- data.frame(
  a = c(1, 2, 3, 4, 5),
  b = c(10, 20, 30, 40, 50),
  c = c("A", "B", "C", "D", "E")  # Columna no numérica
)

## -----------------------------------------------------------------------------
data_estandarizada <- transform_data(data, method = "estandarizacion")
print(data_estandarizada)

## -----------------------------------------------------------------------------
data_normalizada <- transform_data(data, method = "normalizacion")
print(data_normalizada)

